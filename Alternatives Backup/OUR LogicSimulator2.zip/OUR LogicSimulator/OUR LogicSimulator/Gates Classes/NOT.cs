﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace OUR_LogicSimulator
{
   public class NOT : Gate
   {
       public NOT()
       { 
       }

        
    
        public NOT(TextBox Input1, TextBox Out)
       {
           Input[0] = Input1;
           Output = Out;

       }
       public override void calculate()
       {
           int x = Convert.ToInt32(Input[0].Text);
            if (x == 0)
            {
                Output.Text = "1";
            }
            else
            {
                Output.Text = "0";
            }//Output.Text = (~x).ToString();     
       }

        public override void validate()
        {
            int i = 0;
            bool ThereIsNull = false;

            if (Input[i].Text == "" || Input[i].Text == null)
            {
                ThereIsNull = true;
                MessageBox.Show("Please Fill In All The Inputs");
            }

            if (!ThereIsNull)
            {
                calculate();
            }
        }
    }
}
